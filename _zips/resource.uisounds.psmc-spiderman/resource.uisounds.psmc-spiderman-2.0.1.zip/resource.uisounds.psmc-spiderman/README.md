GUI Sounds for the PSMC's Spiderman skin.
