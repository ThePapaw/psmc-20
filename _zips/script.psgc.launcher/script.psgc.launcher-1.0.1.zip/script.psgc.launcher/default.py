from resources import main
main