LaunchBox Launcher - Start LaunchBox Big Box Mode from within PSMC

Question and support available here. 
https://github.com/ThePapaw/psmc-20

This plugin requires a premium license for LaunchBox to allow access to BigBox.
https://www.launchbox-app.com/big-box

This plugin requires PSMC Media Center for Windows as it is a WINDOWS ONLY script.
https://github.com/ThePapaw/psmc-20

Fanart created by The Papaw:

Based from teeedubb's steam launcher addon :
http://forum.kodi.tv/showthread.php?tid=157499
https://github.com/teeedubb

Function solutions/modifications from AutoHotkey Forums, poster credited in ahk script :
https://www.autohotkey.com/boards/viewtopic.php?p=257256#p257256
https://www.autohotkey.com/boards/viewtopic.php?p=173707#p173707